package Flink;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


import org.apache.flink.api.java.DataSet;

import freqitems.util.ItemSet;

public class MainFlink {
public static void main(String[] args) throws Exception {
	
	//preprocessing
	PreprocessingFlink p = new PreprocessingFlink();
	DataSet<List<Integer>> transactionList=p.preprocessingFlink("./OnlineRetail/OnlineRetail-short.csv");
	
	//writeToCSV(p.itemsSet,"./OnlineRetail/preprocessingResultFlink.csv");  
	writeToCSV(p.transactionListString,"./OnlineRetail/preprocessingResultFlink.csv");
      /**
       * MINING PART
       */
	int minSupport = 2;
    int numIterations = 2;
	DataSet<ItemSet> items = AprioriFlink.mine(transactionList, minSupport, numIterations);
	
	 /**
     * POST PROCESSING
     */
	
	DataSet<List<String>> transactionListMapped = items.flatMap(
            new PostprocessingFlink()).withBroadcastSet(p.itemsSet,
            "itemSet");

	writeToCSV(transactionListMapped,"./OnlineRetail/aprioriResultFlink.csv");
}



public static <E> void writeToCSV(DataSet<List<E>> ds, String csvPath) throws Exception{
	 List<List<E>> ll = ds.collect();
   
     StringBuilder sb = new StringBuilder();

     for (List<E> ls : ll) {
         String listString = ls.toString();
         sb.append(listString.substring(1, listString.length()-1));
         sb.append("\n");
     }
     try{
         PrintWriter writer = new PrintWriter(csvPath, "UTF-8");
         writer.println(sb.toString().replace(",", ""));
         writer.close();
     } catch (IOException e) {
     }
}
}
